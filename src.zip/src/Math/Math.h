#include <Arduino.h>

namespace Math {
  uint8_t FloorTen(uint8_t number);
  uint8_t RoundUp(uint8_t a, uint8_t b);
}