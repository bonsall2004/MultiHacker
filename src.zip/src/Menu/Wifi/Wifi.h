#include "../Menu.h"

namespace Wifi 
{
  extern Menu* WifiMenu;
  void CreateMenu();
};